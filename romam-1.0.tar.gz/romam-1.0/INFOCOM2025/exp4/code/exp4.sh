#!/bin/bash

# Print the experiment number
echo "experiment 4"
echo ""

./contrib/romam/NSDI2025/exp4/code/ospf.sh 
./contrib/romam/NSDI2025/exp4/code/ddr.sh
./contrib/romam/NSDI2025/exp4/code/dgr.sh
./contrib/romam/NSDI2025/exp4/code/kshort.sh
./contrib/romam/NSDI2025/exp4/code/octopus.sh